const test = require('./index');

test.handler({});
